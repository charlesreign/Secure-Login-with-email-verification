<?php
/**
 * Created by PhpStorm.
 * User: Charles Reign
 * Date: 7/9/2019
 * Time: 1:50 PM
 */
//mail('charlesgold45@gmail.com','Account Activation','This link is for account activaion','From: charlesgold45@gmail.com');

$email="charlesgold45@gmail.com";
$subject="Account Activation link";
$body="Activate your account by clicking on the link";
$header="From: nextHack.Inc";
if (mail($email,$subject,$body,$header)){
    echo "Activation link sent successfully";
}else{
    echo "Ooops! sending failed";
}




?>