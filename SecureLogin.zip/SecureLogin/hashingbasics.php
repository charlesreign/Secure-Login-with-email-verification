<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Hashing Basics</title>
</head>
<body>

<?php
$password = "mypasswords";
$blowFishHashFormat = "$2y$15$";
$salt = "mynameischarlesreignking";
$blowFistSalt = $blowFishHashFormat.$salt;
$hash = crypt($password,$blowFistSalt);
echo $hash . "<br>";

$token = bin2hex(openssl_random_pseudo_bytes(40));
echo $token;



?>



</body>
</html>