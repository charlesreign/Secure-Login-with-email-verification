<?php
require 'include/functions.php';
require 'include/dbconnect.php';
require 'include/session.php';

if (isset($_GET['token'])) {
    $tokenFomUrl = $_GET['token'];

    if (isset($_POST["submit"])) {
        $password = mysqli_real_escape_string($connection, $_POST["password"]);
        $confpass = mysqli_real_escape_string($connection, $_POST["confpassword"]);

        if (empty($password) || empty($confpass)) {
            $_SESSION["errorMessage"] = "All fields must bbe filled";
        } elseif ($password !== $confpass) {
            $_SESSION["errorMessage"] = "Password do not match";
        } elseif (strlen($password) < 8) {
            $_SESSION["errorMessage"] = "Password mst be more than 8 characters";
        } else {
            $hashPassword = encryption($password);
            $query = "UPDATE `admin_register` SET `password`='$hashPassword' WHERE `token`='$tokenFomUrl'";
            $execute = mysqli_query($connection,$query);
            if ($execute){
                $_SESSION["successMessage"]="Password reset successful";
                redirect("login.php");
            }
            else{
                $_SESSION["errorMessage"] = "!Ooops, something went wrong try again";
                redirect("login.php");
            }


        }
    }
}

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.1.0/css/all.css">
    <title>Create new password</title>
</head>
<body>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-12 col-md-8 col-lg-6 pb-5">
            <!--Form with header-->
            <form method="post" action="">
                <h3 class="display-4" style="margin-bottom: 50px;font-size: 45px; margin-top: 50px">Secure login with email verification</h3>
                <?php echo errorMessage()?>
                <?php echo successMessage()?>
                <div class="card rounded-0">
                    <div class="card-header p-0">
                        <div class="bg-info text-white text-center py-2">
                            <h3 class="display-4">-SignIn-</h3>
                        </div>
                    </div>
                    <div class="card-body p-3">
                        <!--Body-->

                        <div class="form-group">
                            <div class="input-group mb-2">
                                <div class="input-group-prepend">
                                    <div class="input-group-text"><i class="fas fa-lock"></i></div>
                                </div>
                                <input type="password" class="form-control" name="password" placeholder="Enter new password" required>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="input-group mb-2">
                                <div class="input-group-prepend">
                                    <div class="input-group-text"><i class="fas fa-lock"></i></div>
                                </div>
                                <input type="password" class="form-control" name="confpassword" placeholder="Confirm your password" required>
                            </div>
                        </div>
                    </div>
                    <div class="text-center">
                        <input type="submit" value="Reset" name="submit" class="btn btn-info btn-block rounded-0 py-2">
                    </div>
                </div>
            </form>
        </div>

        <!--Form with header-->


    </div>
</div>


<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
</body>
</html>