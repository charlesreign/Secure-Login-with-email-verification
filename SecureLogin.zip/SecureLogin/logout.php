<?php
/**
 * Created by PhpStorm.
 * User: Charles Reign
 * Date: 7/10/2019
 * Time: 12:43 AM
 */
require 'include/session.php';
require 'include/functions.php';
$_SESSION["user_id"]=null;
//this code unsets cookies
$expireTime = time()-86400;
setcookie("SettingEmail",null,$expireTime);
setcookie("SettingUser",null,$expireTime);

session_destroy();
redirect("login.php");