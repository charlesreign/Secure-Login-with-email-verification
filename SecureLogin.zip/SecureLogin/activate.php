<?php
/**
 * Created by PhpStorm.
 * User: Charles Reign
 * Date: 7/9/2019
 * Time: 3:17 PM
 */
require 'include/dbconnect.php';
require 'include/session.php';
require 'include/functions.php';

if (isset($_GET['token'])){
    $tokenFomUrl = $_GET['token'];
    $query = "UPDATE `admin_register` SET `active`='ON' WHERE `token`='$tokenFomUrl'";
    $execute = mysqli_query($connection,$query);
    if ($execute){
        $_SESSION["successMessage"]="Account activation successful";
        redirect("login.php");
    }
    else{
        $_SESSION["errorMessage"] = "Ooops! an error occurred";
        redirect("registration.php");
    }
}