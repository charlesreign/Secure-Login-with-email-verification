<?php
require 'dbconnect.php';

function redirect($newlocation){
    header("Location:".$newlocation);
    exit();
}

//checking if the username already exist
function checkUserExist($email){
    global $connection;
    $query = "SELECT * FROM `admin_register` WHERE `email` = '$email'";
    $execute = mysqli_query($connection,$query);
    if (mysqli_num_rows($execute) > 0){
        return true;
    }
    else{
        return false;
    }
}

function encryption($password){
    //bf-blowfish
    $bfFormat = "$2y$12$";
    $saltLength = 22;
    $salt = generate_salt($saltLength);
    $blowFishSalt = $bfFormat.$salt;
    $hash = crypt($password,$blowFishSalt);
    return $hash;
}

function generate_salt($length){
    $uniqueRandomString =sha1(uniqid(mt_rand(),true));
    $base64String = base64_encode($uniqueRandomString);
    $modifiedBase64String = str_replace('+','.',$base64String);
    $salt = substr($modifiedBase64String,0,$length);
    return $salt;
}

function passwordCheck($password,$existingHash){
    $hash = crypt($password,$existingHash);
    if ($hash === $existingHash){
        return true;
    }
    else{
        return false;
    }
}

function loginAttempt($email,$password){
    global $connection;
    $query = "SELECT * FROM `admin_register` WHERE `email` = '$email'";
    $execute = mysqli_query($connection,$query);
    if ($admin = mysqli_fetch_assoc($execute)){
        if (passwordCheck($password,$admin["password"])){
            return $admin;
        }
    }
    else{
        return null;
    }
}

function confirmAccount(){
    global $connection;
    $query = "SELECT * FROM `admin_register` WHERE `active` = 'ON'";
    $execute = mysqli_query($connection,$query);
    if (mysqli_num_rows($execute) > 0){
        return true;
    }
    else{
        return false;
    }
}

function login(){
    if (isset($_SESSION["user_id"]) || isset($_COOKIE["SettingEmail"])){
        return true;
    }
}

function confirmLogin(){
    if (!login()){
        $_SESSION["errorMessage"] = "Ooops!, login required";
        redirect("login.php");
    }
}