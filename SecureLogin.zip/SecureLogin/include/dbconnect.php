<?php
/**
 * Created by PhpStorm.
 * User: Charles Reign
 * Date: 7/6/2019
 * Time: 11:00 PM
 */

$host = "localhost";
$user = "root";
$pass = "";
$DBname = "securelogin";

$connection = mysqli_connect($host,$user,$pass,$DBname);

if ($connection->connect_errno) {
    die("ERROR : -> ".$connection->connect_error);
}

