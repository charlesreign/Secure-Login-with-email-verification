<?php
require 'include/functions.php';
require 'include/dbconnect.php';
require 'include/session.php';

if (isset($_POST["submit"])){
    $email = mysqli_real_escape_string($connection,$_POST["email"]);

    if (empty($email)){
        $_SESSION["errorMessage"] = "Email field required";
        redirect("forgetpassword.php");
    }

    elseif (!checkUserExist($email)){
        $_SESSION["errorMessage"] = "Email not found";
        redirect("registration.php");
    }
    else{
        $insertData = "SELECT * FROM `admin_register` WHERE `email` = '$email'";
        $execute = mysqli_query($connection,$insertData);
        if ($admin=mysqli_fetch_array($execute)){
            $admin["username"];
            $admin["token"];
            //this code send email to the user into his/her email account
            $subject="Reset password link";
            $body="Hello! ".$admin["username"]." here is the link to reset your account 
            http://localhost/SecureLogin/resetpassword.php?token=".$admin["token"];
            $header="From: nextHack.Inc";
            if (mail($email,$subject,$body,$header)){
                $_SESSION["successMessage"]="Check email for link to reset password ";
                redirect("login.php");
            }else{
                $_SESSION["errorMessage"] = "Ooops! an error occurred, try again later";
                redirect("registration.php");
            }
        }
        else{
            $_SESSION["errorMessage"] = "Ooops! something went wrong, try again";
            redirect("registration.php");
        }
    }
}

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Reset Password</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.1.0/css/all.css">
</head>
<body>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-12 col-md-8 col-lg-6 pb-5">
            <!--Form with header-->
            <form method="post" action="">
                <h3 class="display-4" style="margin-bottom: 50px;font-size: 45px; margin-top: 50px">Secure login with email verification</h3>
                <?php echo errorMessage()?>
                <?php echo successMessage()?>
                <div class="card rounded-0">
                    <div class="card-header p-0">
                        <div class="bg-info text-white text-center py-2">
                            <h3 class="display-4">-Reset Password-</h3>
                        </div>
                    </div>
                    <div class="card-body p-3">
                        <!--Body-->
                        <div class="form-group">
                            <div class="input-group mb-2">
                                <div class="input-group-prepend">
                                    <div class="input-group-text"><i class="fas fa-user"></i></div>
                                </div>
                                <input type="email" class="form-control" name="email" placeholder="Enter email" required>
                            </div>
                        </div>

                    </div>
                    <div class="text-center">
                        <input type="submit" value="Submit" name="submit" class="btn btn-info btn-block rounded-0 py-2">
                    </div>
                </div>
            </form>
        </div>

        <!--Form with header-->


    </div>
</div>

<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>

</body>
</html>