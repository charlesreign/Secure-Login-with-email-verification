<?php
require 'include/functions.php';
require 'include/dbconnect.php';
require 'include/session.php';

if (isset($_POST["login"])){
    $email = mysqli_real_escape_string($connection,$_POST["email"]);
    $password = mysqli_real_escape_string($connection,$_POST["password"]);

    if (empty($email) || empty($password)){
        $_SESSION["errorMessage"] = "All fields must be filled";
        redirect("login.php");
    }
    else{
        if (confirmAccount()){
            $correctAccount = loginAttempt($email,$password);
            if ($correctAccount){
                $_SESSION["user_id"] = $correctAccount['admin-id'];
                $_SESSION["user_name"] = $correctAccount['username'];
                $_SESSION["user_email"] = $correctAccount['email'];

                if (isset($_POST["remember"])){
                    $expireTime = time()+86400;
                    setcookie("SettingEmail",$email,$expireTime);
                    setcookie("SettingUser",$username,$expireTime);
                }
                redirect("index.php");
            }
            else{
                $_SESSION["errorMessage"] = "Invalid email or password";
                redirect("login.php");
            }
        }
        else{
            $_SESSION["errorMessage"] = "Confirm your account using the link sent to your email";
            redirect("login.php");
        }
    }
}



?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.1.0/css/all.css">
    <title>User Login Form</title>
</head>
<body>


<div class="container">
    <div class="row justify-content-center">
        <div class="col-12 col-md-8 col-lg-6 pb-5">
            <!--Form with header-->
            <form method="post" action="">
                <h3 class="display-4" style="margin-bottom: 50px;font-size: 45px; margin-top: 50px">Secure login with email verification</h3>
                <?php echo errorMessage()?>
                <?php echo successMessage()?>
                <div class="card rounded-0">
                    <div class="card-header p-0">
                        <div class="bg-info text-white text-center py-2">
                            <h3 class="display-4">-SignIn-</h3>
                        </div>
                    </div>
                    <div class="card-body p-3">
                        <!--Body-->
                        <div class="form-group">
                            <div class="input-group mb-2">
                                <div class="input-group-prepend">
                                    <div class="input-group-text"><i class="fas fa-user"></i></div>
                                </div>
                                <input type="email" class="form-control" name="email" placeholder="Enter email" required>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="input-group mb-2">
                                <div class="input-group-prepend">
                                    <div class="input-group-text"><i class="fas fa-lock"></i></div>
                                </div>
                                <input type="password" class="form-control" name="password" placeholder="Enter password" required>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="input-group mb-2">
                                <input type="checkbox" name="remember" class="form-check-input" style="margin-left: 5px">
                                <label style="margin-left: 20px" class="form-check-label" for="exampleCheck1">Keep me sign in</label>
                                <a style="margin-left: 250px" href="forgetpassword.php">Forgot Password</a><br>
                            </div>
                        </div>
                    </div>
                    <div class="text-center">
                        <input type="submit" value="Login" name="login" class="btn btn-info btn-block rounded-0 py-2">
                    </div>
                </div>
            </form>
            <p>Don't have an account? <a href="registration.php">Create one</a></p>
        </div>


        <!--Form with header-->


    </div>
</div>
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
</body>
</html>