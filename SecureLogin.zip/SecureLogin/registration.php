<?php
require 'include/functions.php';
require 'include/dbconnect.php';
require 'include/session.php';

if (isset($_POST["submit"])){
    $username = mysqli_real_escape_string($connection,$_POST["username"]);
    $email = mysqli_real_escape_string($connection,$_POST["email"]);
    $password = mysqli_real_escape_string($connection,$_POST["password"]);
    $confpass = mysqli_real_escape_string($connection,$_POST["confpassword"]);
    $token = bin2hex(openssl_random_pseudo_bytes(40));

    if (empty($username) || empty($email) || empty($password) || empty($confpass)){
        $_SESSION["errorMessage"] = "All fields must bbe filled";
        redirect("registration.php");
    }
    elseif ($password !== $confpass){
        $_SESSION["errorMessage"] = "Password do not match";
        redirect("registration.php");
    }
    elseif (strlen($password) < 8){
        $_SESSION["errorMessage"] = "Password mst be more than 8 characters";
        redirect("registration.php");
    }
    elseif (checkUserExist($email)){
        $_SESSION["errorMessage"] = "User already exists";
        redirect("registration.php");
    }
    else{
        $hashPassword = encryption($password);
        $insertData = "INSERT INTO `admin_register`(`username`, `email`, `password`,`token`,`active`) 
                       VALUES ('$username','$email','$hashPassword','$token','OFF')";
        $execute = mysqli_query($connection,$insertData);
        if ($execute){
            //this code send email to the user into his/her email account
            $subject="Account Activation link";
            $body="Hello! ".$username." here is the link to confirm your account 
            http://localhost/SecureLogin/activate.php?token=".$token;
            $header="From: nextHack.Inc";
            if (mail($email,$subject,$body,$header)){
                $_SESSION["successMessage"]="Check email for activation";
                redirect("login.php");
            }else{
                $_SESSION["errorMessage"] = "Ooops! an error occurred, try again later";
                redirect("registration.php");
            }
        }
        else{
            $_SESSION["errorMessage"] = "Ooops! something went wrong, try again";
            redirect("registration.php");
        }
    }
}

?>


<!DOCTYPE html>
<html lang="en" xmlns="http://www.w3.org/1999/html">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.1.0/css/all.css">
    <title>User Registration Form</title>
</head>
<body>

    <div class="container">
        <div class="row justify-content-center">
            <div class="col-12 col-md-8 col-lg-6 pb-5">
                <!--Form with header-->
                <form method="post" action="">
                    <h3 class="display-4" style="margin-bottom: 50px; margin-top: 50px; font-size: 45px">Secure login with email verification</h3>
                    <?php echo errorMessage()?>
                    <?php echo successMessage()?>
                    <div class="card rounded-0">
                        <div class="card-header p-0">
                            <div class="bg-info text-white text-center py-2">
                                <h3 class="display-4">-SignUp-</h3>
                            </div>
                        </div>
                        <div class="card-body p-3">
                            <!--Body-->
                            <div class="form-group">
                                <div class="input-group mb-2">
                                    <div class="input-group-prepend">
                                        <div class="input-group-text"><i class="fas fa-user"></i></div>
                                    </div>
                                    <input type="text" class="form-control" name="username" placeholder="Enter your username" required>
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="input-group mb-2">
                                    <div class="input-group-prepend">
                                        <div class="input-group-text"><i class="fas fa-envelope"></i></div>
                                    </div>
                                    <input type="email" class="form-control" name="email" placeholder="Enter your email address" required>
                                </div>
                                <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>
                            </div>
                            <div class="form-group">
                                <div class="input-group mb-2">
                                    <div class="input-group-prepend">
                                        <div class="input-group-text"><i class="fas fa-lock"></i></div>
                                    </div>
                                    <input type="password" class="form-control" name="password" placeholder="Enter Password" required>
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="input-group mb-2">
                                    <div class="input-group-prepend">
                                        <div class="input-group-text"><i class="fas fa-lock"></i></div>
                                    </div>
                                    <input type="password" class="form-control" name="confpassword" placeholder="Retype Password" required>
                                </div>
                            </div>
                            </div>
                            <div class="text-center">
                                <input type="submit" value="Register" name="submit" class="btn btn-info btn-block rounded-0 py-2">
                            </div>
                        </div>
                </form>
                <p>Already have an account? <a href="login.php">Login</a></p>
            </div>

                <!--Form with header-->

            </div>
        </div>

<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>

</body>
</html>