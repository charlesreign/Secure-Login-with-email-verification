<?php
/**
 * Created by PhpStorm.
 * User: Charles Reign
 * Date: 7/8/2019
 * Time: 11:05 PM
 */
require 'include/session.php';
require 'include/functions.php';
confirmLogin();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.1.0/css/all.css">
    <title>Welcome Page</title>
</head>
<body>

<div class="container-fluid">
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <a class="navbar-brand display-4" href="index.php" style="font-size: 24px">Secure login with email verification</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent" style="margin-left: 60%;">
            <a href="logout.php" class="display-4" style="font-size: 20px; margin-left: 10px; color: white">logout</a>
        </div>
    </nav>

    <h1>Welcome</h1>

    <?php
    if (isset($_SESSION["user_id"])){
        echo "user id is ".$_SESSION["user_id"]." with the name of ".$_SESSION["user_name"].
            " and an email of ". $_SESSION["user_email"];
    }
    if (isset($_COOKIE["SettingUser"])){
        echo "<h2>{$_COOKIE["SettingUser"]}</h2>";
    }
    ?>


    <br>
</div>

</body>
</html>
